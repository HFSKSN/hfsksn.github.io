#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>
#include <Arduino.h>
#include <HardwareSerial.h>
#include <Kalman.h>

// blink
#define LED_R 5
#define LED_B 6

TimerHandle_t blinkTimer = NULL;
bool ledStateRed = false;
bool ledStateBlue = false;

void BlinkCallback(TimerHandle_t xTimer) {
  ledStateRed = !ledStateRed;
  
  if (ledStateRed) {
    digitalWrite(LED_R, HIGH);
  } else {
    digitalWrite(LED_R, LOW);
  }
}

// UART def & func
HardwareSerial MyUART(1);

int RX_PIN = 44;
int TX_PIN = 43;

char START_BYTE_1 = 'A';
char START_BYTE_2 = 'Z';
char END_BYTE_1 = 'Y';
char END_BYTE_2 = 'B';

uint8_t receiveBuffer[10]; // MAKE THIS HOWEVER BIG YOU WANT, NEEDS TO FIT WHATEVER DATA YOU EXPECT TO GET
int i = 0;
int recBytes = 0;
int endBytes = 0;
bool receiving = false;

struct Packet {
    uint8_t sender;
    uint8_t receiver;
    uint8_t type;
};

void sendPacket(uint8_t sender, uint8_t receiver, uint8_t type, uint8_t data_x, uint8_t data_y, uint8_t data_z) {
  MyUART.write(START_BYTE_1);
  MyUART.write(START_BYTE_2);
  MyUART.write(sender);
  MyUART.write(receiver);
  MyUART.write(type);
  MyUART.write(data_x);
  MyUART.write(data_y);
  MyUART.write(data_z);
  MyUART.write(END_BYTE_1);
  MyUART.write(END_BYTE_2);
}

// MPU-6050 def
Adafruit_MPU6050 mpu;

void setup(void) {
  Serial.begin(9600);
  delay(1000);

  // UART setup
  MyUART.begin(9600, SERIAL_8N1, RX_PIN, TX_PIN);
  
  // MPU-6050 setup
  Wire.begin(8,9);

  pinMode(6, OUTPUT); // blue
  pinMode(5, OUTPUT); // red

  while (!Serial)
    delay(10); // will pause Zero, Leonardo, etc until serial console opens

  Serial.println("Adafruit MPU6050 test!");

  // Try to initialize!
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) {
      delay(10);
    }
  }
  Serial.println("MPU6050 Found!");

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  Serial.print("Accelerometer range set to: ");
  switch (mpu.getAccelerometerRange()) {
  case MPU6050_RANGE_2_G:
    Serial.println("+-2G");
    break;
  case MPU6050_RANGE_4_G:
    Serial.println("+-4G");
    break;
  case MPU6050_RANGE_8_G:
    Serial.println("+-8G");
    break;
  case MPU6050_RANGE_16_G:
    Serial.println("+-16G");
    break;
  }
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  Serial.print("Gyro range set to: ");
  switch (mpu.getGyroRange()) {
  case MPU6050_RANGE_250_DEG:
    Serial.println("+- 250 deg/s");
    break;
  case MPU6050_RANGE_500_DEG:
    Serial.println("+- 500 deg/s");
    break;
  case MPU6050_RANGE_1000_DEG:
    Serial.println("+- 1000 deg/s");
    break;
  case MPU6050_RANGE_2000_DEG:
    Serial.println("+- 2000 deg/s");
    break;
  }

  mpu.setFilterBandwidth(MPU6050_BAND_5_HZ);
  Serial.print("Filter bandwidth set to: ");
  switch (mpu.getFilterBandwidth()) {
  case MPU6050_BAND_260_HZ:
    Serial.println("260 Hz");
    break;
  case MPU6050_BAND_184_HZ:
    Serial.println("184 Hz");
    break;
  case MPU6050_BAND_94_HZ:
    Serial.println("94 Hz");
    break;
  case MPU6050_BAND_44_HZ:
    Serial.println("44 Hz");
    break;
  case MPU6050_BAND_21_HZ:
    Serial.println("21 Hz");
    break;
  case MPU6050_BAND_10_HZ:
    Serial.println("10 Hz");
    break;
  case MPU6050_BAND_5_HZ:
    Serial.println("5 Hz");
    break;
  }

  // TIMER
  Serial.println("Starting Timer");
  Serial.println("");

  pinMode(LED_R, OUTPUT);

  blinkTimer = xTimerCreate(
    "BlinkTimer",                   // Timer name
    1000 / portTICK_PERIOD_MS,      // 1s period
    pdTRUE,                         // Auto-reload (periodic timer)
    NULL,                           // Timer ID
    BlinkCallback                   // Callback function
  );
  if (blinkTimer == NULL) {
    Serial.println("Failed to create timer!");
    while (1);
  }

  xTimerStart(blinkTimer, 0); // Start timer immediately
}


int delTime = 0;

void loop() {
  
  // Sensor
  /* Get new sensor events with the readings */
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  /* Print out the values */

  // UART
  if(delTime <  millis())
  {
    sendPacket('H', 'A', 'H', a.acceleration.x, a.acceleration.y, a.acceleration.z);
    sendPacket('H', 'G', 'E', g.gyro.x, g.gyro.y, g.gyro.z);
    delTime = millis() + 2000;
  }

  while (MyUART.available()) {
    uint8_t byte = MyUART.read();

    if (receiving == false && recBytes == 0) { // FIRST "STARTBYTE" DETECTED
        if (byte == START_BYTE_1) {
          recBytes = 1;
          continue;
        }
    }

    if(receiving == false && recBytes == 1) 
    {
      if (byte == START_BYTE_2) // SECOND "STARTBYTE" DETECTED
      {
          receiving = true;
          i = 0;
          recBytes = 0;
          memset(receiveBuffer, 0, sizeof(receiveBuffer)); // Clear the receive buffer since your gonna start filling it up
          continue;
      }
    }

    if (receiving == true) {
        
        
      if (byte == END_BYTE_1 && endBytes == 0) {
        endBytes = 1;
        continue;
      }
      
      if(byte == END_BYTE_2 && endBytes == 1) { //SECOND END BYTE IS DETECTED SO READ ALL THE DATA
          Packet pkt;
          pkt.sender   = receiveBuffer[0];
          pkt.receiver = receiveBuffer[1];
          pkt.type     = receiveBuffer[2];

          for(int e = 0; e < i; e++){
            Serial.println((int8_t)receiveBuffer[e]);
          }

          if((char)pkt.sender != 'A' && (char)pkt.sender != 'B' && (char)pkt.sender != 'C' && (char)pkt.sender != 'D' && (char)pkt.sender != 'E' && (char)pkt.sender != 'F' && (char)pkt.sender != 'G' && (char)pkt.sender != 'H' && (char)pkt.sender != 'I' && (char)pkt.sender != 'J' )
          {
            Serial.println("Stranger danger! I don't know who's sending this!");
            receiving = false;
            i = 0;
            endBytes = 0;
            continue;
          }

          if((char)pkt.receiver == 'H') //IF THE MESSAGE IS FOR ME
          {
            Serial.println("This message is for me!");
            //add whatever you need to do here
          }
          if((char)pkt.receiver == 'X'){
            Serial.println("Beep-Boop, Rollcall");
            digitalWrite(LED_B, HIGH);
            delay(200);
            digitalWrite(LED_B, LOW);
          }
          if((char)pkt.receiver != 'H' && (char)pkt.sender != 'H') //IF ITS NOT FOR ME PASS IT ON
          {
            Serial.println("Pass Along");
            MyUART.write(START_BYTE_1);
            MyUART.write(START_BYTE_2);
            for(int e = 0; e < i; e++)
            {
              MyUART.write(receiveBuffer[e]);
            }
            MyUART.write(END_BYTE_1);
            MyUART.write(END_BYTE_2);
          }

          if((char)pkt.sender == 'H')
          {
            Serial.println("Message looped!");
            receiving = false;
            i = 0;
            endBytes = 0;
            continue;
          }

          receiving = false;
          i = 0;
          endBytes = 0;
          continue;
      }
      else{
        endBytes = 0; //Only saw the first endbyte not the second, so it must have been a fluke
      }

      if(i >= sizeof(receiveBuffer)) //MAKE SURE YOU DONT HAVE A GIANT MESSAGE (THIS CAN HAPPEN IF END BYTES ARE MISSED)
      {
        Serial.println("TOO MUCH DATA");
        receiving = false;
        i = 0;
        endBytes = 0;
        continue;
      }

      receiveBuffer[i++] = byte; //IF THERES NO START OR END BYTE STUFF GOING ON JUST ADD NEW DATA TO THE RECIEVE BUFFER
      }
  }
}